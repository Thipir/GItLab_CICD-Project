module.exports = require('./tools/eslint-rules').rules;
