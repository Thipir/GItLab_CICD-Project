export interface SchematicOptions {
    name: string;
    type: string;
    scope: string;
    platform: string;
}