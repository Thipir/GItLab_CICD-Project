export interface GeneratorOptions {
  name: string;
  author: string;
  favoriteColor: 'brown' | 'red' | 'purple';
}
