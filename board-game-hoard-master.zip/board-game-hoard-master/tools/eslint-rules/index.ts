import ratingFormatterV2 from './rating-formatter-v2';

export const rules = {
    'rating-formatter-v2': ratingFormatterV2
}