"use strict";
exports.__esModule = true;
var rating_formatter_v2_1 = require("./rating-formatter-v2");
exports.rules = {
    'rating-formatter-v2': rating_formatter_v2_1["default"]
};
