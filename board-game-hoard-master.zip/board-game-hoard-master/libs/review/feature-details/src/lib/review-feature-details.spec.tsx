import { cleanup } from '@testing-library/react';

describe(' ReviewFeatureDetails', () => {
  afterEach(cleanup);

  it('should render successfully', () => {});
});
