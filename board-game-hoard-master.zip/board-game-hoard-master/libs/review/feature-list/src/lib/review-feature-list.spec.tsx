import { cleanup } from '@testing-library/react';

describe(' ReviewFeatureList', () => {
  afterEach(cleanup);

  it('should render successfully', () => {});
});
