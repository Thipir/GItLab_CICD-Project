import { cleanup } from '@testing-library/react';

describe(' ReviewUtilFormatters', () => {
  afterEach(cleanup);

  it('should render successfully', () => {});
});
