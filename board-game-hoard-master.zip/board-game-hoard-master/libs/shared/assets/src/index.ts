export * from './lib/shared-assets';
