# angular-publish

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test angular-publish` to execute the unit tests.
