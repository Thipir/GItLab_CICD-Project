# Changelog

This file was generated using [@jscutlery/semver](https://github.com/jscutlery/semver).

## [1.0.1](https://github.com/nrwl/board-game-hoard/compare/angular-publish-1.0.0...angular-publish-1.0.1) (2021-10-08)



# [1.0.0](https://github.com/nrwl/board-game-hoard/compare/angular-publish-0.0.3...angular-publish-1.0.0) (2021-10-08)


### Features

* a fake feature ([5ec5a4c](https://github.com/nrwl/board-game-hoard/commit/5ec5a4c42e4e2fdb5e29bd8b0046154874b045d2))
* breaking change ([5b4204c](https://github.com/nrwl/board-game-hoard/commit/5b4204c14abd6ffe7cc8b89792371564f7bf9fe0))
* second feature ([64e7d61](https://github.com/nrwl/board-game-hoard/commit/64e7d614d6a853c483cfee3c629b1b67cf9919fb))
* third feature ([bac1a09](https://github.com/nrwl/board-game-hoard/commit/bac1a09b4c3d6e0a4984cf4aabbb653cdaa1547e))


### BREAKING CHANGES

* this might break



# [1.0.0](https://github.com/nrwl/board-game-hoard/compare/angular-publish-0.0.3...angular-publish-1.0.0) (2021-10-08)


### Features

* a fake feature ([5ec5a4c](https://github.com/nrwl/board-game-hoard/commit/5ec5a4c42e4e2fdb5e29bd8b0046154874b045d2))
* breaking change ([5b4204c](https://github.com/nrwl/board-game-hoard/commit/5b4204c14abd6ffe7cc8b89792371564f7bf9fe0))
* second feature ([64e7d61](https://github.com/nrwl/board-game-hoard/commit/64e7d614d6a853c483cfee3c629b1b67cf9919fb))
* third feature ([bac1a09](https://github.com/nrwl/board-game-hoard/commit/bac1a09b4c3d6e0a4984cf4aabbb653cdaa1547e))


### BREAKING CHANGES

* this might break



## [0.0.3](https://github.com/nrwl/board-game-hoard/compare/angular-publish-0.0.2...angular-publish-0.0.3) (2021-10-07)


### Bug Fixes

* add another comment ([974d2d5](https://github.com/nrwl/board-game-hoard/commit/974d2d5f93ffc05d660d75f29c2f5518aa6cfdad))



## [0.0.2](https://github.com/nrwl/board-game-hoard/compare/angular-publish-0.0.1...angular-publish-0.0.2) (2021-10-07)



## 0.0.1 (2021-10-07)
