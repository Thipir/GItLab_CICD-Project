# store-ui-formatters

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test store-ui-formatters` to execute the unit tests.
