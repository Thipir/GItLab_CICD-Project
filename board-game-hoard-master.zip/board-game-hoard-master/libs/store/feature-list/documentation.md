Documentation for store-feature-list

This is written by Isaac Mann (whose favorite color is purple)

For more information, see the internal wiki at http://example.com/isaac-mann/store-feature-list
