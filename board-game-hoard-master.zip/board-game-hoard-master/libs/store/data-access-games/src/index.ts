export { GamesService } from './lib/games.service';
export * from './lib/store-data-access-games.module';
