export * from './lib/store-feature-details.module';
