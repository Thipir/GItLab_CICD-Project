# react-publish

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test react-publish` to execute the unit tests via [Jest](https://jestjs.io).
